"use strict";
var endabgabe;
(function (endabgabe) {
    endabgabe.spielerPositionTeam1 = [
        [48, 280, 1], [580, 100, 2], [180, 200, 3], [480, 370, 4], [580, 490, 5], [270, 130, 6], [370, 290, 7], [170, 430, 8], [350, 480, 9], [500, 210, 10], [720, 280, 11]
    ];
    endabgabe.spielerPositionTeam2 = [
        [865, 280, 1], [333, 70, 2], [270, 200, 3], [733, 370, 4], [733, 490, 5], [700, 100, 6], [443, 290, 7], [243, 480, 8], [563, 360, 9], [563, 210, 10], [200, 320, 11]
    ];
    endabgabe.linienrichter = [
        [10, 7], [10, 567]
    ];
    endabgabe.schiedsrichter = [
        [200, 100]
    ];
    endabgabe.tor1 = [
        [48, 229], [48, 385]
    ];
    endabgabe.tor2 = [
        [865, 229], [865, 385]
    ];
    endabgabe.einwurf1 = [
        [52, 50], [880, 50]
    ];
    endabgabe.einwurf2 = [
        [52, 565], [880, 565]
    ];
    endabgabe.ecke1 = [
        [52, 54], [48, 229], [48, 385], [52, 562]
    ];
    endabgabe.ecke2 = [
        [875, 54], [875, 229], [875, 385], [875, 562]
    ];
})(endabgabe || (endabgabe = {}));
//# sourceMappingURL=positionen.js.map